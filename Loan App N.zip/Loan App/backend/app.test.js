const request = require("supertest");
const app = require("./server");

describe("Pust Endpoints", () => {
  it("should create a new put", async () => {
    const res = await request(app).put("/api/infos/1").send({
      fname: "shashank",
    });
    expect(res.statusCode).toEqual(500);
  }, 5000);
});

describe("GET Endpoints", () => {
  it("should create a new get", async () => {
    const res = await request(app).get("/api/infos");
    console.log(res);
    expect(res.statusCode).toEqual(200);
    expect(res.body[0].fname).toEqual("NAGA");
  }, 5000);
});
