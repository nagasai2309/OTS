module.exports = {
    url: "mongodb+srv://nagasai:nagasai8@cluster0.ggoh7.mongodb.net/details?retryWrites=true&w=majority"
  };