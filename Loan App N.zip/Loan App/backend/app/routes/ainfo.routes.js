module.exports = (app) => {
  const ainfo = require("../controllers/ainfo.controller.js");
  var router = require("express").Router();
  // Create a new user
  router.post("/", ainfo.create);
  router.get("/", ainfo.findAll);
  router.put("/:id", ainfo.update);

  app.use("/api/ainfos", router);
};
