const db = require("../models");
const Loan = db.loans;
exports.findAll = async (req, res) => {
  await Loan.find()
    .then((data) => {
      res.send(data);
    })
    .catch((err) => {
      res.status(500).send({
        message: err.message || "Some error occurred while retrieving report.",
      });
    });
};
exports.update = (req, res) => {
  if (!req.body) {
    return res.status(400).send({
      message: "Data to update can not be empty!",
    });
  }
  const id = req.params.id;
  Loan.findByIdAndUpdate(id, req.body, { useFindAndModify: false })
    .then((data) => {
      if (!data) {
        res.status(404).send({
          message: `Cannot update loan with id=${id}. Maybe loan  was not found!`,
        });
      } else res.send({ message: "Loan  was updated successfully." });
    })
    .catch((err) => {
      res.status(500).send({
        message: "Error updating Loan  with id=" + id,
      });
    });
};
exports.delete = (req, res) => {
  const id = req.params.id;
  Loan.findByIdAndRemove(id)
    .then((data) => {
      if (!data) {
        res.status(404).send({
          message: `Cannot delete Loan with id=${id}. Maybe User was not found!`,
        });
      } else {
        res.send({
          message: "Loan was deleted successfully!",
        });
      }
    })
    .catch((err) => {
      res.status(500).send({
        message: "Could not delete Loan with id=" + id,
      });
    });
};
exports.deleteAll = (req, res) => {};
