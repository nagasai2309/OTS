
import React from "react";
import "./App.css";
import Nav from "./components/navigationbar";
import Loandashboard from "./pages/Loandashboard";
import Myprofile from "./pages/Myprofile";
import Accountinfo from "./pages/Accountinfo";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
function App() {
  return (
    <>
      <Router>
        <Nav />
        <Routes>
          <Route path="/" element={<Loandashboard />} />
          <Route path="/loandashboard" element={<Loandashboard />} />
          <Route path="/myprofile" element={<Myprofile />} />
          <Route path="/accountinfo" element={<Accountinfo />} />
        </Routes>
      </Router>
    </>
  );
}

export default App;
