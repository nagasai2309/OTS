import React from "react";
import { Navbar } from "react-bootstrap";
const Navigationbar = () => {
  return (
    <div>
      <hr />
      <Navbar className="navbar">
        <div style={{ paddingLeft: "30px" }}>
          <b>LOGO </b> | Loan Ui
        </div>
      </Navbar>
      <hr />
    </div>
  );
};

export default Navigationbar;
