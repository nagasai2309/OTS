export const sidebardata = [
  {
    title: "Loan Dashboard",
    path: "/loandashboard",
    cName: "nav-text",
  },
  {
    title: "My Profile",
    path: "/myprofile",
    cName: "nav-text",
  },
  {
    title: "Accountant Information",
    path: "/accountinfo",
    cName: "nav-text",
  },
];
