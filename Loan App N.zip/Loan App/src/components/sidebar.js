import React from "react";
import { NavLink } from "react-router-dom";
import "../components/Navbar.css";
import { Navbar } from "react-bootstrap";

const sidebar = () => {
  return (
    <Navbar collapseOnSelect expand="md">
      <Navbar.Toggle />
      <Navbar.Collapse>
        <div>
          <div className="sideNavBar">
            <NavLink
              className="textDec"
              
              to="/loandashboard"
            >
              Loan Dashboard
            </NavLink>
          </div>

          <div className="sideNavBar">
            <NavLink
              className="textDec"
              
              to="/myprofile"
            >
              My Profile
            </NavLink>
          </div>

          <div className="sideNavBar">
            <NavLink
              className="textDec"
              
              to="/accountinfo"
            >
              Accountant Information
            </NavLink>
          </div>
        </div>
      </Navbar.Collapse>
    </Navbar>
  );
};

export default sidebar;
