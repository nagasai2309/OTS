import React, { useState, useEffect } from "react";
import Sidebar from "../components/sidebar";
import { Row, Col, Button } from "react-bootstrap";
import axios from "axios";
import "../components/Navbar.css";

import { toast } from "react-toastify";

import "react-toastify/dist/ReactToastify.css";
toast.configure();
const Myprofile = () => {
  const [formInputs, setformInputs] = useState({
    fname: "",
    lname: "",
    email: "",
    region: "",
  });
  const [errors, setErrors] = useState({});

  useEffect(() => {
    axios
      .get("http://localhost:8080/api/infos")
      .then((response) => {
        const ord = [...response.data];
        setformInputs({
          fname: ord[0].fname,
          lname: ord[0].lname,
          email: ord[0].email,
          region: ord[0].region,
          id: ord[0].id,
        });
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  const onValueChange = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    setformInputs((values) => ({ ...values, [name]: value }));
    console.log(formInputs);
  };
  const handleClick = () => {
    if (validate()) {
      console.log(formInputs);
      axios
        .put(`http://localhost:8080/api/infos/${formInputs.id}`, formInputs)

        .then((res) => {
          console.log(formInputs);
          toast.success("Details Saved Successfully ", {
            position: toast.POSITION.BOTTOM_LEFT,
            autoClose: 3000,
          });
        });
    }
  };

  const validate = () => {
    let isValid = true;
    let error = {};

    if (!formInputs["fname"]) {
      isValid = false;
      error["fname"] = "Please enter your first  name.";
    }
    if (!formInputs["lname"]) {
      isValid = false;
      error["lname"] = "Please enter your last  name.";
    }

    if (typeof formInputs["email"] !== "undefined") {
      var pattern = new RegExp(
        /^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i
      );
      if (!pattern.test(formInputs["email"])) {
        isValid = false;
        error["email"] = "Please enter valid email address.";
      }
    }
    if (!formInputs["region"]) {
      isValid = false;
      error["region"] = "Please enter your region.";
    }

    setErrors(error);

    return isValid;
  };

  return (
    <div className="total">
      <Row>
        <Col sm="3" className="sidebar">
          <Sidebar />
        </Col>
        <Col
          style={{
            paddingRight: "50px",
            paddingLeft: "50px",
            paddingTop: "40px",
          }}
        >
          <div className="header">My Profile</div>
          <div>First Name</div>
          <input
            type="text"
            className="form-control"
            name="fname"
            value={formInputs.fname}
            placeholder="Enter Your First Name"
            onChange={(e) => onValueChange(e)}
            required
          ></input>
          {errors.fname ? <div className="errors">{errors.fname}</div> : null}
          <br></br>
          <div>Last Name</div>
          <input
            type="text"
            className="form-control"
            name="lname"
            value={formInputs.lname}
            placeholder="Enter Your Last Name"
            onChange={(e) => onValueChange(e)}
            required
          ></input>
          {errors.lname ? <div className="errors">{errors.lname}</div> : null}
          <br></br>
          <div>Email Adress</div>
          <input
            type="text"
            className="form-control"
            name="email"
            value={formInputs.email}
            placeholder="Enter Your Email"
            onChange={(e) => onValueChange(e)}
            required
          ></input>
          {errors.email ? <div className="errors">{errors.email}</div> : null}
          <br></br>

          <div>Region</div>
          <input
            type="text"
            className="form-control"
            name="region"
            value={formInputs.region}
            placeholder="Enter Your Region "
            onChange={(e) => onValueChange(e)}
            required
          ></input>
          {errors.region ? <div className="errors">{errors.region}</div> : null}
          <br></br>
          <Button variant="light" style={{ float: "right" }}>
            Cancel
          </Button>
          <Button
            data-testid="button"
            variant="primary"
            style={{ float: "right" }}
            onClick={handleClick}
          >
            Edit
          </Button>
        </Col>
      </Row>
    </div>
  );
};

export default Myprofile;
