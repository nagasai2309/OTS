import { useSelector } from 'react-redux'
import UserDashboard from './login/user/UserDashboard'
import LoginForm from './login/LoginForm'
import AdminDashboard from "./login/admin/AdminDashboard"


function Mdashboard() {

    const selectauthToken = (rootstate) => rootstate.authToken
    const authToken = useSelector(selectauthToken)
    console.log(authToken);

    if (authToken.role === "ADMIN") {
        return (
            
            <>
            <AdminDashboard/>
            
            </>
          
        )
    }
    if (authToken.role === "USER") {
        return (
            <>
            <UserDashboard/>
           
            </>
        )
    }
    return(
        <>
        <LoginForm/>
       
        </>
        )}

export default Mdashboard;