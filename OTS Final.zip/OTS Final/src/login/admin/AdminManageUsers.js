
import React from 'react'
import { useEffect, useMemo, useState } from "react";
import axios from "axios";
import { useTable, usePagination, useGlobalFilter } from "react-table";
import { Table, Button, Row, Col, Container, Card, Form, Modal } from "react-bootstrap";
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import './AdminManageOrders.css'
import dateFormat from 'dateformat';
import configData from "../../config.json";
import Spinner from '../../Spinner/Spinner';

toast.configure()
const AdminManageUsers = () => {
 
  const [orders, setData] = useState([]);
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleCloseAdd = () => setShowadd(false);
  const [showadd, setShowadd] = useState(false);
  const [errors, setErrors] = useState({});
  const [showSpinner, setSpinner] = useState(false);
  const [deletemodal, setDeleteModal] = useState({ id: "", username: "", show: false })
  const [effectrunner, setEffectRunner] = useState(false);
  const [formInputs, setformInputs] = useState({ name: "", email: "", gender: "", password:"",age:"",created: "" });

  const editOrder = (edit) => {
    setSpinner(true);
   
    axios.get(`http://localhost:8080/api/users/${formInputs.id}`)
    orders.map((ord) => {
      if (ord.id === edit.id) {

        setformInputs({ id: ord.id, name: ord.name, email: ord.email, gender: ord.gender, created: ord.created })
        
        setSpinner(false);
   
        setShow(true)
      }
    })
  }
  const handleAddModal = () => {
    setformInputs({ name: "", email: "", gender: "", created: "" })
    setShowadd(true)
  }

  const onValueChange = (e) => {
    const name=e.target.name;
    const value=e.target.value;
    
    setformInputs(values => ({ ...values, [name]: value }))

  }

  const deleteUser = (id, name) => {
    setDeleteModal({ id: id, name: name, show: !deletemodal.show })
}

const handleDelete = (id, name) => {
   setSpinner(true);
      axios.delete(`http://localhost:8080/api/users/${id}`)
          .then(res => {
              console.log(res);
              console.log(res.data);
              setEffectRunner(!effectrunner);
              setDeleteModal({id:"",name:"",show:!deletemodal.show})
              setSpinner(false);
              toast.success(res.data.message, { position: toast.POSITION.BOTTOM_LEFT, autoClose: 3000 })
          })
  
}




  const handleEdit = () => {
    setSpinner(true);
   
     if (validateEdit()) {
    let editdata = {
      id: formInputs.id, name: formInputs.name, email: formInputs.email, gender: formInputs.gender
    }
    // created: formInputs.created

    console.log(editdata);
  
    axios.put(`http://localhost:8080/api/users/${formInputs.id}`, editdata)
      .then(function (response) {
        console.log(response);
        setShow(!show);
   
        setSpinner(false);
   
        toast.success(response.data.message, { position: toast.POSITION.BOTTOM_LEFT, autoClose: 3000 })
      })

     }
  }

  const handleAdd = event => {
    setSpinner(true);
   
    event.preventDefault();
    if (validate()) {
      
      let data={...formInputs}
      console.log(data)
     
      axios.post(`http://localhost:8080/api/users/`,data)
      
        .then(res => {
        
          setformInputs({})
          setShowadd(!showadd);
          setSpinner(false);
   
          toast.success("User was added successfully", { position: toast.POSITION.BOTTOM_LEFT, autoClose: 3000 })
        })
    }
  }

 const validateEdit=()=>{
  let isValid = true;
  let errorEdit = {};

  if (!formInputs["name"]) {
    isValid = false;
    errorEdit["name"] = "Please enter your name.";
  }
  if (!formInputs["email"]) {
    isValid = false;
    errorEdit["email"] = "Please enter your email.";
  }
  if (typeof formInputs["email"] !== "undefined") {

    var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
    if (!pattern.test(formInputs["email"])) {
      isValid = false;
      errorEdit["email"] = "Please enter valid email address.";
    }
  }
  if (!formInputs["gender"]) {
    isValid = false;
    errorEdit["gender"] = "Please select gender.";
  }
  
  setErrors(errorEdit);

  return isValid;

 }




  const validate = () => {

    let isValid = true;
    let error = {};
    
    if (!formInputs["name"]) {
      isValid = false;
      error["name"] = "Please enter your name.";
    }
    if (!formInputs["email"]) {
      isValid = false;
      error["email"] = "Please enter your email.";
    }
    if (typeof formInputs["email"] !== "undefined") {

      var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
      if (!pattern.test(formInputs["email"])) {
        isValid = false;
        error["email"] = "Please enter valid email address.";
      }
    }
    if (!formInputs["password"]) {
      isValid = false;
      error["password"] = "Please enter your password.";
    }
    if (typeof formInputs["password"] !== "undefined") {
      if (formInputs["password"].length < 6) {
        isValid = false;
        error["password"] = "Please add at least 6 character.";
      }
    }
    if (!formInputs["gender"]) {
      isValid = false;
      error["gender"] = "Please select gender.";
    }
    if (!formInputs["age"]) {
      isValid = false;
      error["age"] = "Please select your age.";
    }
    console.log(error);
    setErrors(error);

    return isValid;
  }

  const validName=()=>{
    let error=""
    if (!formInputs["name"]) {  
        error = "Please enter name.";
    }

    else {
        if (formInputs["name"].length < 3) {
            error = "Please add at least 3 character.";
        }
    }
    setErrors(values => ({ ...values, name:error}))

}
const validEmail=()=>{
  let error=""
  if (!formInputs["email"]) {
      
      error= "Please enter your email Address.";
  }

  else {
      var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
      if (!pattern.test(formInputs["email"])) {
          
          error= "Please enter valid email address.";
      }
  }
  setErrors(values => ({ ...values, email:error}))
}
const validPassword=()=>{
  let error=""
  if (!formInputs["password"]) {  
      error = "Please enter password.";
  }

  else {
      if (formInputs["password"].length < 6) {
          error = "Please add at least 6 character.";
      }
  }
  setErrors(values => ({ ...values, password:error}))

}
const validGender=()=>{
  let error=""
  if (!formInputs["gender"]) {  
      error = "Please enter gender.";
  }

  setErrors(values => ({ ...values, gender:error}))

}
const validAge=()=>{
  let error=""
  if (!formInputs["age"]) {  
      error = "Please enter age.";
  }

  setErrors(values => ({ ...values, age:error}))

}







  const COLOMUNS = [
    {
      Header: "ID",
      accessor: "id",
    },
    {
      Header: "Name",
      accessor: "name",
    },
    {
      Header: "Email",
      accessor: "email",
    },
    {
      Header: "Gender",
      accessor: "gender",
    },
    {
      Header: "Created",
      accessor: "createdAt",
    }
  ];

  useEffect(() => {
    const fetchTd = async () => {
      await axios
        .get(`http://localhost:8080/api/users`)
        .then((res) => {
          const ord = [...res.data];
         
            setData(ord);
        });
    };
    fetchTd();
  }, [show, effectrunner,showadd,showSpinner]);

  
  const updatedList = orders.map(item => 
    {
        
        return {...item, createdAt:dateFormat(item.createdAt,configData.DATE_FORMAT,true)}
        
    })
   
  const columns = useMemo(() => COLOMUNS, []);
  const data = useMemo(() => updatedList, [orders]);
  // console.log(data);
  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    page,
    nextPage,
    previousPage,
    canPreviousPage,
    canNextPage,
    pageOptions,
    state,
    setGlobalFilter,
    setPageSize,
    prepareRow,
  } = useTable(
    {
      columns,
      data,
      initialState: { pageIndex: 0 },
    },
    useGlobalFilter,
    usePagination
  );

  const { pageIndex, pageSize, globalFilter } = state;

  

  return (<>
  
 { showSpinner && <Spinner/>}
 
    <title>{configData.TITLE.USERS}</title>
     
      <Container>
        <Row>
          <Card
            style={{ width: "13rem", marginLeft: "20px", marginTop: "20px" }}
          >
            <Card.Body style={{fontSize:"20px"}}>
              <b>Manage Users</b>
            </Card.Body>
          </Card>
        </Row>
        <Row>
          <Col sm={3}></Col>
          <Col sm={5}>
            <input
              class="form-control"
              placeholder="Search Users"
              value={globalFilter || ""}

              onChange={(e) => setGlobalFilter(e.target.value)}
            ></input>
          </Col>
          <Col>
            <Button variant="primary" onClick={handleAddModal} style={{float:"right"}}>Add New User</Button>
          </Col>
        </Row>

        {/* popupwindow for add user*/}

        <Modal show={showadd} onHide={handleCloseAdd}>
          <Modal.Header style={{backgroundColor:"#1266F1"}}>
            <Modal.Title className='modaltitle' >Add New User</Modal.Title>
          </Modal.Header>
          <Modal.Body className='modalform' style={{ overflowY: "scroll", maxHeight: "400px" }}>
            <Form >
              <Form.Group className="mb-3" >
                <div class="form-group required">
                  <Form.Label class='control-label'>Name</Form.Label>
                  <Form.Control onBlur={validName} type="text" placeholder="Enter name" name="name" onChange={(e) => onValueChange(e)} />
                  {errors.name ? <div className="errors">{errors.name}</div> : null}</div>
              </Form.Group>

              <Form.Group className="mb-3">
                <div class="form-group required">
                  <Form.Label class='control-label'>Email Address</Form.Label>
                  <Form.Control onBlur={validEmail} type="email" placeholder="Enter email" name="email" onChange={(e) => onValueChange(e)} />
                  {errors.email ? <div className="errors">{errors.email}</div> : null}</div>
              </Form.Group>

              <Form.Group className="mb-3" >
                <div class="form-group required">
                  <Form.Label class='control-label'>Password</Form.Label>
                  <Form.Control onBlur={validPassword} type="password" placeholder="Password" name="password" onChange={(e) => onValueChange(e)} />
                  {errors.password ? <div className="errors">{errors.password}</div> : null}</div>
              </Form.Group>

              <Form.Group className="mb-3" >
                <div class="form-group required">
                  <Form.Label class='control-label'>Gender</Form.Label>
                  <Form.Check onBlur={validGender}
                    type="radio"
                    id="Male"
                    label="male" name="gender" value="Male" onChange={(e) => onValueChange(e)}

                  />

                  <Form.Check
                    type="radio"
                    id="Female"
                    label="female" name="gender" value="Female" onChange={(e) => onValueChange(e)}

                   />
                  {errors.gender ? <div className="errors">{errors.gender}</div> : null} 
                  </div>
              </Form.Group>

              <Form.Group className="mb-3" >
                <div class="form-group required">
                  <Form.Label class='control-label'>Age</Form.Label>
                  <select onBlur={validAge}className="form-control" name="age" onChange={(e) => onValueChange(e)}>
                    <option value="">Select age</option>
                    <option value="20-30">20-30</option>
                    <option value="30-40">30-40</option>
                    <option value="40 and above">40 and above</option>
                  </select>
                  {errors.age ? <div className="errors">{errors.age}</div> : null}</div>
              </Form.Group>



            </Form>

          </Modal.Body>
          <Modal.Footer style={{backgroundColor:"#1266F1"}}>
            <Button variant="secondary" onClick={handleCloseAdd}>
              Close
            </Button>
            <Button variant="warning" onClick={handleAdd}>
              Add user
            </Button>
          </Modal.Footer>
        </Modal>


{/* edit popup */}

        <Modal show={show} onHide={handleClose}>
          <Modal.Header style={{backgroundColor:"#1266F1"}}>
            <Modal.Title className='modaltitle' >Edit User</Modal.Title>
          </Modal.Header>
          <Modal.Body className='modalform'>
            <Form  >
              <Form.Group class="form-group required" controlId="formUser">
                <Form.Label class='control-label'>Name</Form.Label>
                <Form.Control onBlur={validName}
                  type="text"
                  placeholder="Name"
                  value={formInputs.name}
                  name="name"
                  onChange={(e) => onValueChange(e)}
                  autoFocus
                />{errors.name ? <div className="errors">{errors.name}</div> : null}
              </Form.Group>
              <Form.Group class="form-group required" controlId="formemail">
                <Form.Label class='control-label'>Email</Form.Label>
                <Form.Control onBlur={validEmail}
                  type="email"
                  placeholder="Email"
                  value={formInputs.email}
                  name="email"
                  onChange={(e) => onValueChange(e)}
                />{errors.email ? <div className="errors">{errors.email}</div> : null}
              </Form.Group>
              <Form.Group class="form-group required" controlId="formgender">
                <Form.Label class='control-label'>Gender</Form.Label>
                <Form.Control onBlur={validGender}
                  type="text"
                  placeholder="gender"
                  value={formInputs.gender}
                  name="gender"
                  onChange={(e) => onValueChange(e)}
                />{errors.gender ? <div className="errors">{errors.gender}</div> : null}
              </Form.Group>
              


            </Form>
          </Modal.Body>
          <Modal.Footer style={{backgroundColor:"#1266F1"}}>
            <Button variant="secondary" onClick={handleClose}>
              Close
            </Button>
            <Button variant="warning" onClick={handleEdit}>
              Save Changes
            </Button>
          </Modal.Footer>
        </Modal>


{/* Delete modal */}


        <Modal show={deletemodal.show} onHide={() =>setDeleteModal({ id: "", name: "", show: !deletemodal.show })}>
        <Modal.Title>Confirm Delete</Modal.Title>
                        <Modal.Body>
                            <Row>
                                <Col>
                                    <p>Are you sure to delete user: <b>{deletemodal.name}?</b></p>
                                </Col>
                            </Row>

                            <Row>
                                <Col sm={{ offset: 7, span: 2 }}>
                                    <Button variant="danger" onClick={() => handleDelete(deletemodal.id, deletemodal.name)}>Delete</Button>
                                </Col>
                                <Col sm={{ span: 3 }}>
                                    <Button variant="secondary" onClick={() => setDeleteModal({ id: "", name: "", show: !deletemodal.show })}>Cancel</Button>
                                </Col>
                            </Row>
                        </Modal.Body>
                    </Modal>








        <div style={{overflowX:"auto"}}>
        <Table
          bordered
          hover
          style={{ marginTop: "30px" }}
          {...getTableProps()}
        >
          <thead style={{ backgroundColor: "#1266F1", color: "white" }}>
            {headerGroups.map((headerGroup) => (
              <tr {...headerGroup.getHeaderGroupProps()}>
                {headerGroup.headers.map((column) => (
                  <th {...column.getHeaderProps()}>
                    {column.render("Header")}
                  </th>
                ))}
                <th>Action</th>
              </tr>
            ))}
          </thead>
          <tbody
            {...getTableBodyProps()}
            style={{ backgroundColor: "rgb(212, 237, 245)" }}
          >
            {page.map((row) => {
              prepareRow(row);
              return (
                <tr {...row.getRowProps()}>
                  {row.cells.map((cell) =>
                  (
                    <td {...cell.getCellProps()}>{cell.render("Cell")}</td>
                  )
                  )}
                  <td> <Button variant="warning" onClick={() => editOrder(row.values)}>Edit</Button>{'      '}<Button variant="danger" onClick={() => deleteUser(row.values.id, row.values.name)}>Delete</Button>  </td>
                </tr>
              );
            })}
          </tbody>
        </Table>
        </div>
        <div>
          <Row>
            <Col sm={8}></Col>
            <Col>
              <Button
                variant="primary"
                onClick={() => previousPage()}
                disabled={!canPreviousPage}
              >
                Previous
              </Button>{" "}
              <span>
                Page{" "}
                <strong>
                  {pageIndex + 1} of {pageOptions.length}
                </strong>{" "}
              </span>
              <select
                value={pageSize}
                onChange={(e) => setPageSize(Number(e.target.value))}
              >
                {[5, 10, 50].map((pageSize) => (
                  <option key={pageSize} value={pageSize}>
                    Show {pageSize}
                  </option>
                ))}
              </select>{" "}
              <Button
                variant="primary"
                onClick={() => nextPage()}
                disabled={!canNextPage}
              >
                Next
              </Button>
            </Col>
          </Row>
        </div>
      </Container>
    </>
  );
};
export default AdminManageUsers
