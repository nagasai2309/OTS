import React from 'react'
import {useState,useEffect} from 'react'
import {Row,Col,Card,Button, Container} from 'react-bootstrap'
import axios from'axios';
import './UserMovie.css'
import BookingPage from './BookingPage';
import configData from "../../config.json";

const UserMovies = () => {
  const [show, setShow] = useState(false);
  //let token=false;
  const handleClose = () => setShow(false);
 // const handleShow = () =>setShow(true)

const [searchInput,setSearchInput]=useState("")
const [movies,setMovies]=useState([]);
const [loading,setLoading]=useState(false);
const [moviename,setMoviename]=useState()
const handleShow = (m) =>{setShow(true)  

  //console.log(m)

setMoviename(m)  
}
const handleChange = (e) => {
  e.preventDefault();
  setSearchInput(e.target.value);
  console.log(searchInput);
};

useEffect( ()=>{
  const FetchData=async ()=>{
    setLoading(true);
    //https://jsonblob.com/api/jsonBlob/956015867855126528
    const res= await axios.get(`http://localhost:8080/api/usermovies`).then(res=>{
    const mov=[...res.data];
    setMovies(mov);
    setLoading(false);
  }).catch((err) => console.error(err))
}
FetchData();

console.log(movies);

  },[])

  
    
  return (
    <>
    <title>{configData.TITLE.UMOVIES}</title>
      <Container>
      <Row>
          <Card
             style={{ width: "13rem", marginLeft: "20px", marginTop: "20px" }}
          >
            <Card.Body style={{fontSize:"20px"}}>
              <b>Movies</b>
            </Card.Body>
          </Card>
        </Row>
        <Row style={{marginTop:'20px'}}>
             <Col sm={4}></Col>
             <Col sm={5}><input class="form-control" type="search" onChange={handleChange} placeholder='Search Movies'></input></Col>
         </Row>

          
        <Row >
        {loading?(<h4>isLoading..</h4>):(
          movies.filter(val=>{
            if(searchInput===""){
            return val
            }else if(val.movie.toLowerCase().includes(searchInput.toLowerCase())){
               return val
            }
          })
        .map(item=>(
          <Col sm={4} style={{marginTop:'20px'}}>     
          <Card key={item.id} className='card' style={{width:"19rem",backgroundColor:"white"}} border="success">
          <Card.Img variant="top" className="image" src={item.img} />
          <Card.Body className='movie'>
          
         <Card.Title className='d-flex'><p class="font-weight-light" style={{fontFamily:"sans-serif"}}>Movie Name  :</p><div style={{color:"#800000"}}><b>{item.movie}</b></div></Card.Title>
         <Card.Title className='d-flex'><p class="font-weight-light" style={{fontFamily:"sans-serif"}}>Screen Name  :</p><div style={{color:"#800000"}}>{item.screen}</div></Card.Title>
         <Card.Title className='d-flex'><p class="font-weight-light" style={{fontFamily:"sans-serif"}}>Price :</p><div style={{color:"#800000"}}>{item.price}/-</div></Card.Title>
         <Button variant="success" onClick={()=>handleShow(item.movie)} style={{float:"right",width:"100%"}}>Book now</Button>

        </Card.Body>
         </Card>
         </Col>
        )))}
       </Row>   
         
           </Container>

            {show&&<BookingPage show={show} handleClose={handleClose} movie={moviename}  method={setShow} />}
           
    </>
  )
}

export default UserMovies