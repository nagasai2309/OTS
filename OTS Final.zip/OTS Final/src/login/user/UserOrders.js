import React from "react";
import { useEffect, useMemo, useState } from "react";
import axios from "axios";
import { useTable, usePagination, useGlobalFilter } from "react-table";
import { Table, Button, Row, Col, Container, Card } from "react-bootstrap";
import configData from "../../config.json";
import dateFormat from 'dateformat';
const UserOrders = () => {
  const [orders, setData] = useState([]);
  const COLOMUNS = [
    {
      Header: "ID",
      accessor: "id",
    },
    {
      Header: "Movie",
      accessor: "movie",
    },
    {
      Header: "Tickets",
      accessor: "tickets",
    },
    {
      Header: "Total",
      accessor: "total",
    },
    {
      Header: "Created",
      accessor: "createdAt",
    },
  ];

  useEffect(() => {
    const fetchTd = async () => {
      await axios
      //https://jsonblob.com/api/jsonBlob/956128188216655872
        .get("http://localhost:8080/api/aorders")
        .then((res) => {
          const ord = [...res.data];
          setData(ord);
        });
    };
    fetchTd();
  }, []);


  const updatedList = orders.map(item => 
    {
        
        return {...item, createdAt:dateFormat(item.createdAt,configData.DATE_FORMAT,true)}
        //return{...item,created:new Intl.DateTimeFormat("en-IN","mmmm dd, yyyy" ).format(item.created)}
        // configData.DATE_FORMAT_OBJECT
    })

  //console.log(orders);
  const columns = useMemo(() => COLOMUNS, []);
  const data = useMemo(() => updatedList, [orders]);
  
  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    page,
    nextPage,
    previousPage,
    canPreviousPage,
    canNextPage,
    pageOptions,
    state,
    setGlobalFilter,
    setPageSize,
    prepareRow,
  } = useTable(
    {
      columns,
      data,
      initialState: { pageIndex: 0 },
    },
    useGlobalFilter,
    usePagination
  );

  const { pageIndex, pageSize, globalFilter } = state;

  return (
    <>
    <title>{configData.TITLE.UORDERS}</title>
      <Container>
        <Row>
          <Card
            style={{ width: "13rem", marginLeft: "20px", marginTop: "20px" }}
          >
            <Card.Body style={{fontSize:"20px"}}>
              <b>User Orders</b>
            </Card.Body>
          </Card>
        </Row>
        <Row>
          <Col sm={3}></Col>
          <Col sm={5}>
            <input
              class="form-control"
              placeholder="Search Orders"
              value={globalFilter || ""}
              onChange={(e) => setGlobalFilter(e.target.value)}
            ></input>
          </Col>
          {/* <Col sm={4}><input  className="form-control" type="search" placeholder='Search User'></input></Col> */}
        </Row>

        <Table
          bordered
          hover
          style={{ marginTop: "30px" }}
          {...getTableProps()}
        >
          <thead style={{ backgroundColor: "#1266F1", color: "white" }}>
            {headerGroups.map((headerGroup) => (
              <tr {...headerGroup.getHeaderGroupProps()}>
                {headerGroup.headers.map((column) => (
                  <th {...column.getHeaderProps()}>
                    {column.render("Header")}
                  </th>
                ))}
              </tr>
            ))}
          </thead>
          <tbody
            {...getTableBodyProps()}
            style={{ backgroundColor: "rgb(212, 237, 245)" }}
          >
            {page.map((row) => {
              prepareRow(row);
              return (
                <tr {...row.getRowProps()}>
                  {row.cells.map((cell) => {
                    return (
                      <td {...cell.getCellProps()}>{cell.render("Cell")}</td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </Table>
        <div>
          <Row>
            <Col sm={8}></Col>
            <Col>
              <Button
                variant="primary"
                onClick={() => previousPage()}
                disabled={!canPreviousPage}
              >
                Previous
              </Button>{" "}
              <span>
                Page{" "}
                <strong>
                  {pageIndex + 1} of {pageOptions.length}
                </strong>{" "}
              </span>
              <select
                value={pageSize}
                onChange={(e) => setPageSize(Number(e.target.value))}
              >
                {[5, 10, 50].map((pageSize) => (
                  <option key={pageSize} value={pageSize}>
                    Show {pageSize}
                  </option>
                ))}
              </select>{" "}
              <Button
                variant="primary"
                onClick={() => nextPage()}
                disabled={!canNextPage}
              >
                Next
              </Button>
            </Col>
          </Row>
        </div>
      </Container>
    </>
  );
};

export default UserOrders;


