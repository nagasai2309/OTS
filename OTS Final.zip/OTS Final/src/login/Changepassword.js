import React from 'react' 
import {Card,Form,Row,Col,Button,Container} from 'react-bootstrap'
import {toast} from 'react-toastify';
import {useState} from 'react'
import './Changepassword.css'
import { Link } from 'react-router-dom';
import 'react-toastify/dist/ReactToastify.css';
import configData from '../config'
toast.configure()



function Changepassword() {
    const [inputs,setinputs]=useState({})
    const [errors, setErrors] = useState({});
   
   
    const handleChange = event => {
     setinputs(values=>({...values,[event.target.name]:event.target.value}));
   } 
   const handleSubmit = event => {
     event.preventDefault();
     if (validate()) {
    setinputs({...inputs})
     console.log(inputs)
   
       toast.success('Password Changed Successfully', {position: toast.POSITION.BOTTOM_LEFT,autoClose:3000})
   
    }
    }
 


   
    const validate = () => {

        let isValid = true;
        let error = {};
    
        
       
        if (typeof inputs["email"] !== "undefined") {

          var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
          if (!pattern.test(inputs["email"])) {
            isValid = false;
            error["email"] = "Please enter valid email address.";
          }
        }
        if (!inputs["cpassword"]) {
          isValid = false;
          error["cpassword"] = "Please enter your password.";
        }
        if (typeof inputs["cpassword"] !== "undefined") {
          if (inputs["cpassword"].length < 6) {
            isValid = false;
            error["cpassword"] = "Please add at least 6 character.";
          }
        }

        if (!inputs["npassword"]) {
            isValid = false;
            error["npassword"] = "Please enter your password.";
          }
          if (typeof inputs["npassword"] !== "undefined") {
            if (inputs["npassword"].length < 6) {
              isValid = false;
              error["npassword"] = "Please add at least 6 character.";
            }
          }
          setErrors(error);

          return isValid;
        }
      



  return (
    <Container>
      <title>{configData.TITLE.APP_TITLE}</title>
      <Row>
          <Card
            style={{ width: "15rem", marginLeft: "20px", marginTop: "20px" }}
          >
            <Card.Body style={{fontSize:"20px"}}>
              <b>Change Password</b>
            </Card.Body>
          </Card>
        </Row>
      
      
      
      <Row><Col sm={4}></Col>
    <Col sm={4}>
      <Card style={{ width: '25rem', marginTop:'50px' , backgroundColor:'#1266F1' }}>
   
      <Card.Header className='cyp' >Change Your Password</Card.Header>

  
  <Card.Body style={{backgroundColor:'rgb(212, 237, 245)'}}>
  <Form onSubmit={handleSubmit}>
   
   

  <Form.Group className="mb-3">
  <div className="form-group required">
    <Form.Label  className='control-label'>Current Password</Form.Label>
    <Form.Control type="password" name="cpassword"  placeholder="Enter Current Password"  onChange={handleChange} />
    {errors.cpassword?<div className="errors">{errors.cpassword}</div>:null}</div>
    </Form.Group>

  <Form.Group className="mb-3">
  <div className="form-group required">
    <Form.Label  className='control-label'>New Password</Form.Label>
    <Form.Control type="password" name="npassword" placeholder="Enter New Password"  onChange={handleChange} />
    {errors.npassword?<div className="errors">{errors.npassword}</div>:null}</div>
  </Form.Group>

  <Button type='submit'> Submit</Button>
  {" "}
  <Button variant="secondary"><Link style={{textDecoration:"none",color:"white"}} to="/" > Cancel</Link></Button>
  </Form>
  </Card.Body>
</Card></Col><Col sm={4}></Col>
</Row>
    </Container>
  )
}

export default Changepassword
