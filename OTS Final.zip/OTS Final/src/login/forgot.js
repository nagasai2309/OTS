import React,{useState} from 'react'
import { Card,Form ,Button,Row,Col} from 'react-bootstrap'
import { Link } from 'react-router-dom';
import {toast} from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import configData from '../config'
toast.configure()
const Forgot = () => {
  const [errors, setErrors] = useState({});
  const [inputs, setinputs] = useState({});
const handleSubmit=(event)=>{
  event.preventDefault();
if(validate()){
  toast.success('Mail Sent Successfully', {position: toast.POSITION.BOTTOM_LEFT,autoClose:3000})
}
}

const handleChange = event => {
  setinputs(values=>({...values,[event.target.name]:event.target.value}));
} 

const validate = () => {

  let isValid = true;
  let error = {};

  if (!inputs["email"]) {
    isValid = false;
    error["email"] = "Please enter your email address.";
  }

  if (typeof inputs["email"] !== "undefined") {

    var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
    if (!pattern.test(inputs["email"])) {
      isValid = false;
      error["email"] = "Please enter valid email address.";
    }
  }
  setErrors(error);

  return isValid;
}
  return (
    <div>
      <title>{configData.TITLE.APP_TITLE}</title>
      <Row>
        <Col sm={4}></Col>
        <Col>
   <Card style={{color:'white',backgroundColor:'rgb(212, 237, 245)', width: '25rem',marginTop:'150px' }}>
   <Card.Header className='register' style={{backgroundColor:"#1266F1"}}><b> FORGOT PASSWORD</b></Card.Header>
  <Card.Body>
    <Form onSubmit={handleSubmit}>
    {/* <Card.Title style={{color:'#1266F1'}}>CHANGE PASSWORD</Card.Title> */}
  <Form.Group className="form-group required">
    <Form.Label className='control-label'>Enter Registered Email</Form.Label>
    <Form.Control type="text"  placeholder="Enter email"  name="email" onChange={handleChange}/>
    {errors.email?<div className="errors">{errors.email}</div>:null}
  </Form.Group>
  <Button type='submit'>Submit</Button>{" "}
  <Button type='button' variant="secondary"><Link to="/"  style={{textDecoration:"none",color:"white"}}>Back</Link></Button>
  </Form>
  </Card.Body>

</Card>
</Col>
</Row>
</div>
  )
}

export default Forgot;
