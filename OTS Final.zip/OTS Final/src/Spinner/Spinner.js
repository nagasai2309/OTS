import React from 'react'
import Img from "./Spinner-1s-200px.svg"
const Spinner = () => {
  return (
    <div>
      <img src={Img} alt="...h"></img>
    </div>
  )
}

export default Spinner
