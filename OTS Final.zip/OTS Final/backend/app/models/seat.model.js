module.exports = mongoose => {
    var schema = mongoose.Schema(
      {
        rowname:String,
        seats:Array,
        title:String,stat:String
      },
      { timestamps: true }
    );
    schema.method("toJSON", function() {
      const { __v, _id, ...object } = this.toObject();
      object.id = _id;
      return object;
    });
    const sseat = mongoose.model("sseat", schema);
    return sseat;
  };