module.exports = mongoose => {
    var schema = mongoose.Schema(
      {
        username:String,
        movie:String,
        total:Number
      },
      { timestamps: true }
    );
    schema.method("toJSON", function() {
      const { __v, _id, ...object } = this.toObject();
      object.id = _id;
      return object;
    });
    const report = mongoose.model("report", schema);
    return report;
  };