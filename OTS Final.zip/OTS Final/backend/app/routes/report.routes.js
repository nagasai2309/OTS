module.exports = app => {
    const report = require("../controllers/report.controller.js");
    var router = require("express").Router();
    router.get("/", report.findAll);
    app.use('/api/reports', router);
  };