module.exports = app => {
    const sseat = require("../controllers/seat.controller.js");
    var router = require("express").Router();
    router.get("/", sseat.findAll);
    router.put("/:id", sseat.update);
    app.use('/api/sseats', router);
  };
  