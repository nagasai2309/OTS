module.exports = app => {
    const auser = require("../controllers/auser.controller.js");
    var router = require("express").Router();
    // Create a new user
    router.post("/", auser.create);
    // Retrieve all users
    router.get("/", auser.findAll);
     
    
    // Update a user with id
    router.put("/:id", auser.update);
    // Delete a user with id
    router.delete("/:id",auser.delete);
  
    router.get("/:id", auser.findOne);
    app.use('/api/ausers', router);
  };