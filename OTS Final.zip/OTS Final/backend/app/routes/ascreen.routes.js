module.exports = app => {
    const screen = require("../controllers/screen.controller.js");
    var router = require("express").Router();
    // Create a new user
    router.post("/", screen.create);
    // Retrieve all users
    router.get("/", screen.findAll);
     
    
    // Update a user with id
    router.put("/:id", screen.update);
    // Delete a user with id
    router.delete("/:id",screen.delete);
    // Delete all
   
    app.use('/api/screens', router);
  };